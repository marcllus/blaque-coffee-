const { Configuration, OpenAIApi } = require("openai");

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

exports.handler = async function(event, context) {
  const { name, blend } = JSON.parse(event.body);
  const prompt = `Write a cinematic, luxurious short story about a person named ${name} who chooses the ${blend} blend from Blaque Coffee. The story should be mystical, urban, and immersive—like a scene from a late-night dream.`;
  try {
    const completion = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.9,
      max_tokens: 300,
    });
    const story = completion.data.choices[0].message.content;
    return {
      statusCode: 200,
      body: JSON.stringify({ story }),
    };
  } catch (error) {
    console.error("OpenAI error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Story generation failed." }),
    };
  }
};
